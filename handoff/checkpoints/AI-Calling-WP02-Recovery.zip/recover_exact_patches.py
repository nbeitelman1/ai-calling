"""Replay only complete, visible edits; verify prior recorded SHA-256 receipts.

This does NOT recreate the missing closing_runtime.py or incomplete test source.
Recovered fragments are kept apart from the runnable f112070 checkout.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/tool_results/ai-calling-wp02')
OUT = Path('/workspace/tool_results/wp02-recovery/recovered-source')
PATCHES = {
 'server/closing_state.py': [
  ("    'caller_goodbye': (GOODBYE_LINE, True),", "    'caller_goodbye': (GOODBYE_LINE, True),\n    'assistant_goodbye': (GOODBYE_LINE, True),"),
  ("    'pipeline_error': (GOODBYE_LINE, False),", "    'pipeline_error': (GOODBYE_LINE, False),\n    'tts_limit': (GOODBYE_LINE, False),"),
 ],
 'server/prewarm_phrases.py': [
  ('from model_select import REFUSAL_LINE\n', 'from model_select import REFUSAL_LINE\nfrom closing_state import GOODBYE_LINE\n'),
  ('PHRASES = {\n    DISCLOSURE_OPENING,', 'PHRASES = {\n    GOODBYE_LINE,\n    DISCLOSURE_OPENING,'),
 ],
 'server/live_server.py': [
  ('        if any(cache.load(phrase) is None for phrase in phrases):\n            failures.append("phrase_cache")',
   '        from closing_runtime import closing_enabled\n        if closing_enabled():\n            from closing_state import GOODBYE_LINE\n            phrases = (*phrases, GOODBYE_LINE)\n        if any(cache.load(phrase) is None for phrase in phrases):\n            failures.append("phrase_cache")'),
 ],
 'server/live_pipeline.py': [
  ('    def on_user_text(self, text: str) -> dict:\n', '    def on_user_text(self, text: str, *, observe_tracker: bool = True) -> dict:\n'),
  ('        if self.tracker is not None:\n            self.tracker.observe_user(text)', '        if observe_tracker and self.tracker is not None:\n            self.tracker.observe_user(text)'),
  ('        if isinstance(frame, LLMFullResponseStartFrame):\n            self._active = True\n            self._buffer = []\n            await self.push_frame(frame, direction)\n            return\n        if isinstance(frame, LLMFullResponseEndFrame):\n            full = "".join(self._buffer)\n            self._buffer = []\n            self._active = False\n            action = self._ladder.on_assistant_text(full)',
   '        closing = getattr(self._ladder, \'closing_runtime\', None)\n        if isinstance(frame, LLMFullResponseStartFrame):\n            self._response_epoch = closing.epoch if closing else 0\n            self._active = True\n            self._buffer = []\n            if not closing or not closing.closing:\n                await self.push_frame(frame, direction)\n            return\n        if isinstance(frame, LLMFullResponseEndFrame):\n            full = "".join(self._buffer)\n            self._buffer = []\n            self._active = False\n            if closing and (closing.closing or getattr(self, \'_response_epoch\', -1) != closing.epoch):\n                return\n            action = self._ladder.on_assistant_text(full)\n            if closing and (self._ladder.terminal_reason or action[\'action\'] == \'loop_in_nathan\'):\n                # The controller speaks its cached line, not this generated copy.\n                if full.strip():\n                    self._ladder.transcript.pop()\n                closing.request(self._ladder.terminal_reason or \'loop_in_requested\')\n                return'),
  ('                safe = "I\'ve reached the call\'s speaking limit, so I\'ll end here. Goodbye."\n                await self.push_frame(TextFrame(text=safe), direction)',
   '                if closing:\n                    closing.request(\'tts_limit\')\n                    return\n                safe = "I\'ve reached the call\'s speaking limit, so I\'ll end here. Goodbye."\n                await self.push_frame(TextFrame(text=safe), direction)'),
  ('                safe = self._apply_repetition_guard(safe, tracker)\n                tracker.observe_assistant(safe)\n            if safe:',
   '                safe = self._apply_repetition_guard(safe, tracker)\n                tracker.observe_assistant(safe)\n            if closing and self._ladder.terminal_reason:\n                if full.strip():\n                    self._ladder.transcript.pop()\n                closing.request(self._ladder.terminal_reason)\n                return\n            if safe:'),
  ('    stream_id = call_data["stream_id"]\n    call_control_id = call_data["call_id"]',
   '    from closing_runtime import (\n        ClosingRuntime, ClosingInputGate, ClosingContextGate, ClosingOutputGate,\n        closing_enabled,\n    )\n    owned_closing = closing_enabled()\n    stream_id = call_data["stream_id"]\n    call_control_id = call_data["call_id"]'),
  ('        api_key=_resolve_ref(refs.telnyx_api_key_ref),\n        adapter=adapter,',
   '        api_key=_resolve_ref(refs.telnyx_api_key_ref),\n        params=TelnyxFrameSerializer.InputParams(auto_hang_up=not owned_closing),\n        adapter=adapter,'),
  ('    aggregators = LLMContextAggregatorPair(context)\n\n    pipeline = Pipeline([',
   '    closing = None\n    if owned_closing:\n        from pipecat.processors.aggregators.llm_response_universal import LLMUserAggregatorParams\n        from runtime_safety import timeout_setting\n        idle_seconds = timeout_setting(\'AI_CALLING_SILENCE_SECONDS\', 12)\n        aggregators = LLMContextAggregatorPair(context, user_params=LLMUserAggregatorParams(\n            user_idle_timeout=idle_seconds))\n        closing = ClosingRuntime(job.brief, ladder, activity, phrase_cache, context, idle_seconds)\n        closing.llm = llm\n        closing.user_aggregator = aggregators.user()\n        ladder.closing_runtime = closing\n        aggregators.user().add_event_handler(\'on_user_turn_idle\', closing.on_idle)\n        aggregators.user().add_event_handler(\'on_user_turn_stop_timeout\', closing.on_empty_timeout)\n        aggregators.user().add_event_handler(\'on_user_turn_stopped\', closing.on_user_turn_stopped)\n    else:\n        aggregators = LLMContextAggregatorPair(context)\n\n    pipeline = Pipeline(['),
  ('        TranscriptTap(ladder, "user", silence_policy),\n        aggregators.user(),\n        llm,',
   '        ClosingInputGate(closing) if closing else TranscriptTap(ladder, "user", silence_policy),\n        aggregators.user(),\n        *([ClosingContextGate(closing)] if closing else []),\n        llm,'),
  ('        BotActivityTap(activity),\n        transport.output(),', '        BotActivityTap(activity),\n        *([ClosingOutputGate(closing)] if closing else []),\n        transport.output(),'),
  ('                              audio_out_sample_rate=tts_sample_rate),',
   '                              # Pace 8 kHz phone audio before packetization;\n                              # serializer resampling otherwise skips empty writes.\n                              audio_out_sample_rate=8000 if closing else tts_sample_rate),'),
  ('                          "phrase_cache": phrase_cache,\n                          "call_control_id": call_control_id,', '                          "phrase_cache": phrase_cache,\n                          "closing": closing,\n                          "call_control_id": call_control_id,'),
  ('    async def reprompt():\n        text = "Are you still there?"',
   '    closing = services.get(\'closing\')\n    closing_task = None\n\n    async def dispatch_hangup(adapter_arg, attempt_id, api_key, reason):\n        async def invoke(actual_reason):\n            return await _hangup_via_adapter(adapter_arg, attempt_id, api_key, actual_reason)\n        if closing:\n            return await closing.hangup_once(invoke, reason)\n        return await invoke(reason)\n\n    async def reprompt():\n        text = "Are you still there?"'),
  ('        silence_task = spawn(_wait_for_silence(\n            services["activity"], services["silence_policy"],\n            silence_seconds, reprompt), "silence")\n        done, _pending = await asyncio.wait(\n            {runner_task, watcher_task, limit_task, frontier_task, terminal_task,\n             cost_task, silence_task},\n            return_when=asyncio.FIRST_COMPLETED)',
   '        if closing:\n            # Existing watchers only supply reasons. Their old termination\n            # branches are not entered on the controller path.\n            closing_task = spawn(closing.run({limit_task: \'duration\', frontier_task: \'frontier\',\n                                             terminal_task: \'terminal\', cost_task: \'cost\'}), \'closing\')\n            silence_task = None\n            wait_set = {runner_task, watcher_task, closing_task}\n        else:\n            silence_task = spawn(_wait_for_silence(\n                services["activity"], services["silence_policy"],\n                silence_seconds, reprompt), "silence")\n            wait_set = {runner_task, watcher_task, limit_task, frontier_task, terminal_task,\n                        cost_task, silence_task}\n        done, _pending = await asyncio.wait(wait_set, return_when=asyncio.FIRST_COMPLETED)'),
  ('        elif limit_task in done:\n            hangup_acknowledged = await _finish_and_hangup(',
   '        elif closing_task is not None and closing_task in done:\n            outcome = closing_task.result()\n            await task.queue_frame(EndFrame())\n            try:\n                await asyncio.wait_for(asyncio.shield(runner_task), timeout=3.0)\n            except asyncio.TimeoutError:\n                await runner.cancel(\'closing drain timeout\')\n            hangup_acknowledged = await dispatch_hangup(\n                adapter, media_token, _resolve_ref(refs.telnyx_api_key_ref), outcome)\n            end_time = time.time()\n        elif limit_task in done:\n            hangup_acknowledged = await _finish_and_hangup('),
  ('                hangup_acknowledged = await _hangup_via_adapter(\n                    adapter, media_token, _resolve_ref(refs.telnyx_api_key_ref), outcome)\n            await runner.cancel(outcome)',
   '                hangup_acknowledged = await dispatch_hangup(\n                    adapter, media_token, _resolve_ref(refs.telnyx_api_key_ref), outcome)\n            await runner.cancel(outcome)'),
  ('                outcome = "cancelled"\n                hangup_acknowledged = await _hangup_via_adapter(', '                outcome = "cancelled"\n                hangup_acknowledged = await dispatch_hangup('),
  ('                exc = runner_task.exception()\n                outcome = f"error:{type(exc).__name__}"\n                hangup_acknowledged = await _hangup_via_adapter(',
   '                exc = runner_task.exception()\n                outcome = f"error:{type(exc).__name__}"\n                hangup_acknowledged = await dispatch_hangup('),
  ('            hangup_acknowledged = await asyncio.shield(\n                _hangup_via_adapter(', '            hangup_acknowledged = await asyncio.shield(\n                dispatch_hangup('),
  ('    except Exception as exc:  # noqa: BLE001 - record, don\'t swallow silently\n        outcome = f"error:{type(exc).__name__}"\n        end_time = time.time()\n        try:\n            hangup_acknowledged = await _hangup_via_adapter(',
   '    except Exception as exc:  # noqa: BLE001 - record, don\'t swallow silently\n        outcome = f"error:{type(exc).__name__}"\n        end_time = time.time()\n        try:\n            hangup_acknowledged = await dispatch_hangup('),
  ('            "hangup_acknowledged": hangup_acknowledged,\n            "hangup_required": not (hangup_acknowledged or carrier_reconciliation.get("hangup_event")),',
   '            "hangup_acknowledged": hangup_acknowledged,\n            "closing": closing.summary() if closing else {"mode": "legacy"},\n            "hangup_required": not (hangup_acknowledged or carrier_reconciliation.get("hangup_event")),'),
  ("            message = json.loads(serialized)\n            if message.get('event') == 'media':", "            message = json.loads(serialized)\n            if message.get('event') == 'clear' and getattr(frame, 'closing_ack', None):\n                frame.closing_ack.set()\n            if message.get('event') == 'media':"),
  ('            safe = limit_spoken_response(sanitize_outgoing(full), self._ladder.stage())\n            if (safe and self._character_budget',
   '            safe = limit_spoken_response(sanitize_outgoing(full), self._ladder.stage())\n            if closing:\n                from closing_state import is_goodbye_intent\n                if is_goodbye_intent(full):\n                    if full.strip():\n                        self._ladder.transcript.pop()\n                    closing.request(\'assistant_goodbye\')\n                    return\n            if (safe and self._character_budget'),
  ('                else:\n                    outcome = "completed"\n            end_time = time.time()\n        else:  # pragma: no cover - wait always returns a done task',
   '                else:\n                    outcome = "completed"\n            if closing:\n                # With serializer auto-hangup disabled, even an unexpected\n                # normal runner exit must close the billable leg exactly once.\n                hangup_acknowledged = await dispatch_hangup(\n                    adapter, media_token, _resolve_ref(refs.telnyx_api_key_ref), outcome)\n            end_time = time.time()\n        else:  # pragma: no cover - wait always returns a done task'),
  ('                 "gemini_requests": sum(\n                     1 for turn in ladder.transcript if turn["role"] == "assistant"),',
   '                 "gemini_requests": closing.llm_requests if closing else sum(\n                     1 for turn in ladder.transcript if turn["role"] == "assistant"),'),
 ],
}
PATCHES['tools/offline_verify.py'] = [
 ("p.add_argument('--pattern',default='test*.py')", "p.add_argument('--pattern',default='test*.py')\np.add_argument('--test', action='append', default=[], help='Focused dotted unittest name')"),
 ("suite=unittest.defaultTestLoader.discover(str(root/'tests'),pattern=a.pattern)", "if a.test:\n    sys.path.insert(0,str(root/'tests'))\n    suite=unittest.defaultTestLoader.loadTestsFromNames(a.test)\nelse:\n    suite=unittest.defaultTestLoader.discover(str(root/'tests'),pattern=a.pattern)"),
]
PATCHES['tools/generate_turn_fixtures.py'] = [
 ("    'real_question': 'Wait, what time are you open?',", "    'real_question': 'Opening hours?',\n    'confirmation': 'Confirmation.',\n    'handback': \"Nathan will need to take this over. I'll end the call now.\",\n    'silence_close': \"I haven't heard anything, so I'll end the call now. Goodbye.\",\n    'human_request': 'Please let me talk to a human.',\n    'objective_complete': 'Office appointment available time bring confirmation.',"),
 ("'idle_prompt','goodbye_reply','closing_line')", "'idle_prompt','goodbye_reply','closing_line','handback','silence_close')"),
]
EXPECTED = {
 'tools/generate_turn_fixtures.py': '4dfb45f4e0969d4a3cb4f4e1a52bb03e57406fc4c683875d4db2f36f1b2fd4c3',
 'tools/offline_verify.py': '896f006cbe78ffff9da090a22b40e71c91f89390cb50282d47fcac3b98b15c40',
 'server/closing_state.py': '4efc26923afbf87a917bf04af0753e3d12d904529045cebb5d446389a1c6994b',
 'server/prewarm_phrases.py': '6708ddf8b07c0596d90d3c70ca812746e343044fe384f1d72fd5aafb8ef788c1',
 'server/live_server.py': 'f66124301edea9c5e3e6aae73c4f7bd17669b285f494a1cba0ae53434939993b',
 'server/live_pipeline.py': 'c72f30377e0d16cc4dcd3bde2cf8762afe215869bd6170142861086dea8fd51d',
}
results = []
for relative, patches in PATCHES.items():
    text = (ROOT / relative).read_text()
    for index, (old, new) in enumerate(patches):
        assert text.count(old) == 1, (relative, index, text.count(old))
        text = text.replace(old, new)
    content = text.encode()
    digest = hashlib.sha256(content).hexdigest()
    assert digest == EXPECTED[relative], (relative, digest)
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    results.append({'file': relative, 'sha256': digest, 'bytes': len(content), 'exact_prior_hash_match': True})
receipt = {'status': 'PARTIAL_SOURCE_RECOVERED_NOT_RUNNABLE', 'files': results,
           'missing_required_module': 'server/closing_runtime.py',
           'runtime_tests_revalidated': False}
(OUT.parent / 'exact-patch-recovery.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
