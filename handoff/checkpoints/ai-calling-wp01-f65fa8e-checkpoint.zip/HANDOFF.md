# AI Calling — WP-1 recoverable implementation checkpoint

- **Branch:** `agile/wp-01-turn-stack`
- **HEAD:** `f65fa8e0bf2d7fcff3a38437006e4d86d2ebbd38`
- **Reviewed base:** `ffaf4ccf4450359d3a87728906521316f8e562d4`
- **Status:** implementation and scoped offline acceptance passed; review/publication pending.
- **Not performed:** live calls, provider API calls, deployment, push, or merge.

This replaces the earlier inventory-only d9fe3dc checkpoint for continuing WP-1 work.

## Contents

- `ai-calling.bundle`: complete Git history reachable from the package branch, without local Git configuration or credentials.
- `source.zip`: exact committed source tree, including tests, synthetic WAVs, package report and evidence.
- `logs/offline-qa/`: current and historical synthetic verification attempts, including failures.
- `CHECKPOINT.json`: current mission state and exact HEAD.
- `WP01_TURN_STACK_REPORT.md`: mechanics, measured sample statistics, reproduction commands, flags, limits and deferred work.
- `SHA256SUMS.json`: byte hashes for the archive's contents, excluding the hash manifest itself.
- `restore-check.json`: verification of an actual offline restore from the Git bundle.

## Restore without contacting GitHub

```bash
git clone -b agile/wp-01-turn-stack ai-calling.bundle ai-calling-wp01
cd ai-calling-wp01
git rev-parse HEAD
```

Expected HEAD is `f65fa8e0bf2d7fcff3a38437006e4d86d2ebbd38`. Follow the report's commands in a Python 3.12 environment using the unchanged hash-locked requirements. Do not run dialing or deployment scripts. The source ZIP is an alternative if history is not needed.

## Evidence

- 281/281 application tests; zero failures/errors/skips.
- 57/57 reference tests, 3/3 reference mutations caught, 28-file manifest verified.
- 6/6 new isolated turn-stack mutations caught at intended assertions; zero harness errors.
- 21 fresh benchmark runs, with raw samples and source hashes retained.
- Pattern-based secret/new-identifier scan passed; not an exhaustive DLP certification.

## Important decisions

The explicit stack is opt-in. Keep `AI_CALLING_TURN_STACK=legacy` until review. The appointment-only completeness experiment is separately off by default and should stay off: it suppresses a scripted premature answer but increases corrected-response delay in the latest sample. No production p95, recognition quality or handset playout claim is supported by this synthetic bench.

## Next work

WP-2 is the single-owner CLOSING state machine. It has not been implemented. Follow the reviewed-base branch rule and do not silently merge or stack WP-1. Secure authenticated access is needed before publishing; do not reuse any previously posted token. Publication, integration and deployment are distinct actions.
