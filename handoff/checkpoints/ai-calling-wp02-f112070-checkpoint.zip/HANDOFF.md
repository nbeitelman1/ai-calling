# WP-2 intermediate checkpoint — controller verified, runtime integration pending

**Branch:** `agile/wp-02-closing-state`  
**HEAD:** `f11207098baa6dd9429f8675068a9ec0d607fc32`  
**Parent:** reviewed candidate `ffaf4ccf4450359d3a87728906521316f8e562d4`

This is NOT a completed WP-2 runtime fix. `server/live_pipeline.py` remains unchanged. The new pure controller and TurnRouter integration pass 35 new state/API tests, and the complete independent branch passes 285 tests. A real-service, scripted-client baseline still reproduces two goodbyes with no natural close.

## Restore offline

```bash
git clone -b agile/wp-02-closing-state ai-calling.bundle ai-calling-wp02
cd ai-calling-wp02
git rev-parse HEAD
```

The ZIP also contains the exact committed `source.zip`, report, state, raw offline logs, SHA-256 manifest and a verified bundle-restore receipt. No credentials, live databases or local Git configuration are packaged.

## Evidence

- 285/285 application tests (250 reviewed baseline + 28 state/router + 7 native contracts).
- 57/57 reference tests, 3/3 reference mutations caught, 28-file manifest verified.
- 6/6 isolated controller mutations caught at intended assertions.
- 4,096 bounded event combinations, within one of the state tests.
- Valid two-goodbye baseline with real service classes, synthetic speech and scripted provider clients; 0 network attempts and 0 pending cleanup tasks.

## Next

Read `docs/WP02_CLOSING_REPORT.md` section 5. Integrate one runtime owner for closing, cached audio, completion and hangup; remove competing termination effects rather than wrapping them. Cover cached audio missing, genuine reopening versus acknowledgement, delayed batch STT, stale events, in-flight model replies, hard caps and native idle rearming. Then repeat end-to-end and full-suite acceptance. Do not proceed to WP-3 yet.

WP-1 is a separate branch at f65fa8e; it is not merged into this branch. No branch was pushed, no live calls or provider API calls were made, and nothing was deployed or merged.
